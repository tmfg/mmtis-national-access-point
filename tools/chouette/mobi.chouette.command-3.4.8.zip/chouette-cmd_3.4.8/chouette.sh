#!/bin/bash

java -Xmx1024M -jar mobi.chouette.command-3.4.8.jar $*
